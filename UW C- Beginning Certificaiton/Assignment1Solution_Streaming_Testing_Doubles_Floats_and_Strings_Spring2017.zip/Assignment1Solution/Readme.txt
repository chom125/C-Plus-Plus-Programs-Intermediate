The CppUnitLite framework, testcode, and application code is provided in this single package for ease of compilation and running.

In a production program (and in many of your solutions) CppUnitLite is packaged in its own library, the test code is in its own executable,
and the classes, functions, and other elements of your program are packaged into their own library.